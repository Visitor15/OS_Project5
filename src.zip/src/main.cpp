/*
 * main.cpp
 *
 *  Created on: Nov 1, 2013
 *      Author: visitor15
 */


#include "computer.h"

int main() {

	Computer::powerOn();

	return EXIT_SUCCESS;
}
